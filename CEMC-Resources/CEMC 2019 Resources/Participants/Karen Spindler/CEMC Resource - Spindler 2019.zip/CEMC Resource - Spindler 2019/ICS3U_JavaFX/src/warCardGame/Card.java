package warCardGame;

import java.net.URL;

public class Card {
    
    /** Two-character string to defining a single card; 
     * 1st char is the name (T = 10, J = 11, Q = 12, K = 13, A = 14)
     * 2nd char is the suit (C = clubs, D = diamonds, H = hearts, S = spades)
     */
    String name;

    public Card(String name) {
        this.name = name;
    }

    /**
     * default constructor: shows back of card - card has no value
     */
    public Card() { 
        this("XX");
    }

    /**
     * uses the name of the card to get the correct image file
     * @return Image representing this card
     */
    public String getCardImageName() {
        String filename = "/CARDS/" + name + ".jpg";

        URL file = getClass().getResource(filename);

        return file.toString();
    }

    /**
     * gets the numeric value of the card
     * @return an int representing the value of the card, (jack = 11, queen = 12, king = 13, ace = 14)
     */
    public int getCardValue() {
        char cValue = name.charAt(0);

        int cardValue = 0;

        // get the name of the card for display purposes
        if (Character.isDigit(cValue)) { // card 2 - 9
            cardValue = Character.getNumericValue(cValue);
        } else if (cValue == 'T') { // card 10
            cardValue = 10;
        } else if (cValue == 'J') {
            cardValue = 11;
        } else if (cValue == 'Q') {
            cardValue = 12;
        } else if (cValue == 'K') {
            cardValue = 13;
        } else if (cValue == 'A') { // aces high
            cardValue = 14;
        }
        return cardValue;
    }

    /**
     * identifies the suit
     * @return char H = Hearts, C = Clubs, D = Diamonds, S = Spades
     */
    public char getSuit() {
        return name.charAt(1);
    }

}
