package activity3;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Stars extends Application {

    static final double SCREEN_WIDTH = 1024;
    static final double SCREEN_HEIGHT = 768;

    static final int NUM_STARS = 1000;
    static final double MAX_SPEED = 15.0;
    static final double MIN_SPEED = 1;

    static final double STAR_SIZE = 1.5;

    double[] starAngle = new double[NUM_STARS];
    double[] starSpeed = new double[NUM_STARS];

    Circle[] stars = new Circle[NUM_STARS];

    Scene scene;

    @Override
    public void start(Stage myStage) throws Exception {

        for (int i = 0; i < stars.length; i++) {

            // give each star a random location to begin
            double xStart = getRandomXLocation(), yStart = getRandomYLocation();

            stars[i] = new Circle(xStart, yStart, STAR_SIZE, Color.WHITE);

            // based on its location, determine the angle needed to appear to come from the
            // center
            starAngle[i] = getAngle(xStart, yStart);
            starSpeed[i] = getRandomSpeed();
        }

        Group root = new Group(stars);

        scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);
        scene.setFill(Color.BLACK);

        StarsTimer timer = new StarsTimer();
        timer.start();

        myStage.setTitle("Stars!");
        myStage.setScene(scene);
        myStage.show();

    }

    double getRandomSpeed() {
        return Math.random() * (MAX_SPEED - MIN_SPEED) + MIN_SPEED;
    }

    double getRandomXLocation() {
        return Math.random() * SCREEN_WIDTH;
    }

    double getRandomYLocation() {
        return Math.random() * SCREEN_HEIGHT;
    }

    double getAngle(double xStart, double yStart) {
        double angle = 0;
        double centerX = SCREEN_WIDTH / 2, centerY = SCREEN_HEIGHT / 2;

        // angle in quadrant 1
        angle = Math.atan(Math.abs((yStart - centerY) / (xStart - centerX)));

        if (xStart < centerX && yStart < centerY) {
            // Quadrant 3
            angle += Math.PI;
        } else if (xStart > centerX && yStart < centerY) {
            // Quadrant 4
            angle = 2 * Math.PI - angle;
        } else if (xStart < centerX && yStart > centerY) {
            // Quadrant 2
            angle = Math.PI - angle;
        }

        return angle;
    }

    double getRandomAngle() {
        return Math.random() * 2 * Math.PI;
    }

    class StarsTimer extends AnimationTimer {

        @Override
        public void handle(long now) {
            // get current width and height; user may have resized
            double width = scene.getWidth();
            double height = scene.getHeight();

            for (int i = 0; i < stars.length; i++) {

                // check boundary collision
                Bounds box = stars[i].getBoundsInLocal();

                // check edges of screen
                if (box.getMinX() < 0 || box.getMaxX() > width || box.getMinY() < 0 || box.getMaxY() > height) {
                    // reposition start in the middle; with new random speed & direction
                    stars[i].setCenterX(width / 2);
                    stars[i].setCenterY(height / 2);
                    starAngle[i] = getRandomAngle();
                    starSpeed[i] = getRandomSpeed();
                } else {
                    // otherwise, just move the star towards the edge of the screen
                    stars[i].setCenterX(stars[i].getCenterX() + Math.cos(starAngle[i]) * starSpeed[i]);
                    stars[i].setCenterY(stars[i].getCenterY() + Math.sin(starAngle[i]) * starSpeed[i]);
                }
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
