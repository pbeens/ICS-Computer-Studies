package activity4;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.media.AudioClip;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Pong extends Application {

    // initial size of screen; game still works after resize
    static final int SCREEN_WIDTH = 800;
    static final int SCREEN_HEIGHT = 600;
    // Constants for speed and size of objects in the game
    final int BALL_SIZE = 5;
    final int BALL_SPEED = 5;
    final int PADDLE_HEIGHT = 75;
    final int PADDLE_WIDTH = 5;
    final int PADDLE_OFFSET = 10;
    final int COMPUTER_PADDLE_SPEED = 5;
    final int USER_PADDLE_SPEED = 10;
    final int FONT_SIZE = 20;
    // Controls direction of the ball
    final short TOWARDS_USER = 1;
    final short TOWARDS_COMPUTER = -1;

    // Speed of the paddle; only moves up & down
    double dYPaddle = 0;
    // Speed of the ball
    double dX = BALL_SPEED;
    double dY = BALL_SPEED;
    // direction of the ball; positive means towards user;
    // negative is towards computer
    short direction = TOWARDS_COMPUTER;

    // shapes for the game
    Circle ball;
    Rectangle userPaddle, computerPaddle;

    // controls the animation
    GameTimer timer;
    // Reference for screen
    Scene scene;
    // Play sound when ball hits paddle
    AudioClip sound;

    // Keep score
    int userScore = 0, computerScore = 0;
    Text txtUserScore, txtComputerScore;

    @Override
    public void start(Stage myStage) throws Exception {

        // Create Game elements - 2 paddles and a ball
        ball = new Circle(BALL_SIZE);
        userPaddle = new Rectangle(SCREEN_WIDTH - (PADDLE_WIDTH + PADDLE_OFFSET), SCREEN_HEIGHT / 2, PADDLE_WIDTH,
                PADDLE_HEIGHT);
        computerPaddle = new Rectangle(PADDLE_OFFSET, SCREEN_HEIGHT / 2, PADDLE_WIDTH, PADDLE_HEIGHT);

        txtUserScore = new Text("Player: " + userScore);
        txtUserScore.setFont(Font.font(FONT_SIZE));
        txtUserScore.setX(SCREEN_WIDTH - txtUserScore.maxWidth(FONT_SIZE));
        txtUserScore.setY(FONT_SIZE);
        txtComputerScore = new Text(0, FONT_SIZE, "Computer : " + computerScore);
        txtComputerScore.setFont(Font.font(FONT_SIZE));

        // add all elements to the scene graph
        Group root = new Group(ball, userPaddle, computerPaddle, txtUserScore, txtComputerScore);

        // animation timer to update and render graphics
        timer = new GameTimer();
        timer.start();

        sound = new AudioClip(Pong.class.getResource("/sounds/pong.mp3").toString());

        // Create the scene and set it to respond to user events
        scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);
        scene.setOnKeyPressed(event -> handleKeyPressed(event));
        scene.setOnKeyReleased(event -> handleKeyReleased(event));

        // Set up the stage
        myStage.setTitle("Pong");
        myStage.setScene(scene);
        newBall();
        myStage.show();

    }

    class GameTimer extends AnimationTimer {
        @Override
        public void handle(long now) {
            // get bounds for checking collisions
            Bounds ballBounds = ball.getBoundsInLocal();
            Bounds userBounds = userPaddle.getBoundsInLocal();
            Bounds computerBounds = computerPaddle.getBoundsInLocal();

            // ball - check top & bottom of screen
            if (ballBounds.getMinY() < 0 || ballBounds.getMaxY() > scene.getHeight())
                dY *= -1; // reverse direction

            // paddles - check for ball hitting the paddles
            // ball on computer's side
            if (ballBounds.getMinX() < computerBounds.getMaxX()) {
                if (ballBounds.intersects(computerBounds)) {
                    // ball has been returned
                    direction = TOWARDS_USER;
                    sound.play();
                } else {
                    // computer missed the ball
                    userScore++;
                    txtUserScore.setText("Player: " + userScore);
                    // ensure all of the text is still visible
                    txtUserScore.setX(scene.getWidth() - txtUserScore.maxWidth(FONT_SIZE));
                    newBall();
                }
            }
            // ball on user's side
            if (ballBounds.getMaxX() > userBounds.getMinX()) {
                if (ballBounds.intersects(userBounds)) {
                    // ball has been returned
                    direction = TOWARDS_COMPUTER;
                    sound.play();
                } else {
                    // user missed the ball
                    computerScore++;
                    txtComputerScore.setText("Computer: " + computerScore);
                    newBall();
                }
            }
            // reposition ball for the next frame
            ball.setCenterX(ball.getCenterX() + dX * direction);
            ball.setCenterY(ball.getCenterY() + dY);
            // reposition paddles for the next frame
            userPaddle.setY(userPaddle.getY() + dYPaddle);
            computerPaddle.setY(computerPaddle.getY() + moveTowardsBall(ballBounds, computerBounds));

            // if user resizes the screen, move the user's paddle
            userPaddle.setX(scene.getWidth() - (PADDLE_WIDTH + PADDLE_OFFSET));
        }
    }

    /*
     * Method that handles key input from the user
     */
    private void handleKeyPressed(KeyEvent event) {
        KeyCode code = event.getCode();

        // Direction arrows - move the paddle
        if (code == KeyCode.UP || code == KeyCode.KP_UP) {
            dYPaddle = -USER_PADDLE_SPEED;
        } else if (code == KeyCode.DOWN || code == KeyCode.KP_DOWN) {
            dYPaddle = USER_PADDLE_SPEED;
        } else if (code == KeyCode.SPACE) {
            // pause the game
            timer.stop();
        } else if (code == KeyCode.ENTER) {
            // restart the game
            timer.start();
        }

    }

    /*
     * Makes the paddle stop moving when the user release the directional key
     */
    private void handleKeyReleased(KeyEvent event) {
        KeyCode code = event.getCode();

        if (code == KeyCode.UP || code == KeyCode.KP_UP || 
                code == KeyCode.DOWN || code == KeyCode.KP_DOWN) {
            dYPaddle = 0;
        }
    }

    /*
     * Basic AI - computer will move towards the ball and stay still if the ball is
     * in its range
     */
    int moveTowardsBall(Bounds ballBounds, Bounds computerBounds) {
        int speed;

        if (ballBounds.getMinY() <= computerBounds.getMinY())
            // ball is higher, move paddle upwards
            speed = -COMPUTER_PADDLE_SPEED;
        else if (ballBounds.getMaxY() >= computerBounds.getMaxY())
            // ball is lower, move paddle downwards
            speed = COMPUTER_PADDLE_SPEED;
        else
            // ball must be at the same level as the paddle
            speed = 0;

        return speed;
    }

    /*
     * Create a random number within the range specified
     */
    double getRandomNumber(int low, int high) {
        int range = high - low + 1;
        return Math.random() * range + low;
    }

    /*
     * Create a new ball in the middle of the screen with a randomized speed, within
     * the range expected
     */
    void newBall() {
        // ensure a little variation each time with the ball's speed
        dX = getRandomNumber(BALL_SPEED - 1, BALL_SPEED + 1);
        dY = getRandomNumber(BALL_SPEED - 1, BALL_SPEED + 1);

        // place the ball in the middle of the screen
        ball.setCenterX(scene.getWidth() / 2);
        ball.setCenterY(scene.getHeight() / 2);
    }

    public static void main(String[] args) {
        launch(args);
    }

}
