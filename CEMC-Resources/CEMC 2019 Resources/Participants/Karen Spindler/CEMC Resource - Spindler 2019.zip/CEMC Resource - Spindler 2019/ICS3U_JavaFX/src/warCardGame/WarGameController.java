package warCardGame;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class WarGameController {

    /**
     * Visible elements on the screen
     */
    @FXML
    ImageView playerCard;
    @FXML
    ImageView computerCard;

    @FXML
    Label lblComputerScore;
    @FXML
    Label lblPlayerScore;

    /**
     * Deck object to handle dealing and shuffling
     */
    Deck playingDeck;

    /**
     * Default card - shows the back of any card
     */
    Card backOfCard;

    public WarGameController() {
        super();
        playingDeck = new Deck();
        backOfCard = new Card();
    }

    @FXML
    public void playRound(ActionEvent e) {

        // Card for the user
        Card player = playingDeck.dealNextCard();
        playerCard.setImage(new Image(player.getCardImageName()));

        // Card for the computer
        Card computer = playingDeck.dealNextCard();
        computerCard.setImage(new Image(computer.getCardImageName()));

        // Determine the winner
        if (player.getCardValue() > computer.getCardValue()) {
            // Player wins
            int currentScore = Integer.parseInt(lblPlayerScore.getText());
            lblPlayerScore.setText(String.valueOf(currentScore + 1));
        } else if (player.getCardValue() < computer.getCardValue()) {
            // Computer wins
            int currentScore = Integer.parseInt(lblComputerScore.getText());
            lblComputerScore.setText(String.valueOf(currentScore + 1));
        }

    }

    @FXML
    public void shuffle(ActionEvent e) {
        //shuffle the deck
        playingDeck.shuffleDeck();
        
        //give user feedback; turn the cards to their backs
        playerCard.setImage(new Image(backOfCard.getCardImageName()));
        computerCard.setImage(new Image(backOfCard.getCardImageName()));

    }

}
