package warCardGame;

public class Deck {

    // Standard 52-card deck; 1st char is the name (T = 10, J = 11, Q = 12, K = 13, A = 14)
    // 2nd char is the suit (C = clubs, D = diamonds, H = hearts, S = spades)
    final static private String[] DECK = {  "2C", "3C", "4C", "5C", "6C", "7C", "8C", "9C", "TC", "JC", "QC", "KC", "AC",
                                            "2D", "3D", "4D", "5D", "6D", "7D", "8D", "9D", "TD", "JD", "QD", "KD", "AD", 
                                            "2H", "3H", "4H", "5H", "6H", "7H", "8H", "9H", "TH", "JH", "QH", "KH", "AH", 
                                            "2S", "3S", "4S", "5S", "6S", "7S", "8S", "9S", "TS", "JS", "QS", "KS", "AS" };

    // Sentinel
    final static private int NO_CARDS_LEFT = -1;

    // keep track of which cards are dealt to avoid repeats
    boolean[] isDealt;

    // keep track of # of cards dealt, know when deck is done
    int cardCounter;

    /**
     * Default constructor 
     */
    public Deck() {

        // boolean array initialization defaults to false
        isDealt = new boolean[DECK.length];

        // new deck; no cards dealt
        cardCounter = 0;

    }

    /**
     *  gets the next random card; will return the back of the card when the deck runs out
     * @return the next Card to be dealt
     */

    public Card dealNextCard() {

        Card nextCard;

        int cardNumber = randomCardNumber();

        if (cardNumber == NO_CARDS_LEFT)
            nextCard = new Card(); // display the card back
        else
            nextCard = new Card(DECK[cardNumber]);

        return nextCard;
    }

    /**
     * chooses a random number for a card; ensures no repeats
     * @return an int representing the index of the card being dealt
     */
    private int randomCardNumber() {
        
        int cardNumber;
        // make sure there are still cards left in the deck
        if (cardCounter == DECK.length) {
            cardNumber = NO_CARDS_LEFT; // sentinel to indicate no more cards!
        } else {
            // keep going until we find a unique card
            do {
                // choose a random card in the deck array
                cardNumber = (int) (Math.random() * DECK.length);
            } while (isDealt[cardNumber]); // try again if 'dealt' already

            // keep track of which card was dealt for the next time
            isDealt[cardNumber] = true;

            // counting cards
            cardCounter++;
        }
        return cardNumber;
    }

    /**
     * makes all cards available again
     */
    public void shuffleDeck() {
        // reset the card counter
        cardCounter = 0;

        // reset the boolean array
        isDealt = new boolean[DECK.length];
    }
}
