package activity3;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class BallBounce extends Application {

    static final double SCREEN_WIDTH = 800;
    static final double SCREEN_HEIGHT = 600;

    static final double MAX_SPEED = 5.0;
    static final double BALL_SIZE = 40.0;

    double dX = MAX_SPEED;
    double dY = MAX_SPEED;

    Circle ball;

    @Override
    public void start(Stage myStage) throws Exception {

        ball = new Circle(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, BALL_SIZE);
        Group root = new Group(ball);

        BounceTimer timer = new BounceTimer();
        timer.start();

        Scene scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);

        myStage.setTitle("Bouncing Ball!");
        myStage.setScene(scene);
        myStage.show();
    }

    class BounceTimer extends AnimationTimer {

        @Override
        public void handle(long now) {
            // check boundary collision
            Bounds box = ball.getBoundsInLocal();
            
            //check edges of screen
            if (box.getMinX() < 0 || box.getMaxX() > SCREEN_WIDTH)
                dX *= -1;
            if (box.getMinY() < 0 || box.getMaxY() > SCREEN_HEIGHT)
                dY *= -1;

            //reposition ball for the next frame
            ball.setCenterX(ball.getCenterX() + dX);
            ball.setCenterY(ball.getCenterY() + dY);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
