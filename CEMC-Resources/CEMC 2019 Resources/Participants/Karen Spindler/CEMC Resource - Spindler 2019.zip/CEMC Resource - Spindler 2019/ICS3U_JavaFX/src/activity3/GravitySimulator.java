package activity3;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class GravitySimulator extends Application {

    // Constants for size & speeds of objects
    static final double SCREEN_WIDTH = 800;
    static final double SCREEN_HEIGHT = 600;

    private final int BALL_SIZE = 20;
    private final int INITAL_SPEED = 30;
    private final int ANGLE = 65;
    private final double GRAVITY = 1;

    double dX;
    double dY;

    Circle ball;
    
    Scene scene;

    @Override
    public void start(Stage myStage) throws Exception {

        ball = new Circle(BALL_SIZE, SCREEN_HEIGHT - BALL_SIZE, BALL_SIZE);
        
        //start ball moving to the right
        dX = INITAL_SPEED * Math.cos(Math.toRadians(ANGLE));
        
        //start ball moving up
        dY = - INITAL_SPEED * Math.sin(Math.toRadians(ANGLE));

        Group root = new Group(ball);

        scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);

        GravityTimer timer = new GravityTimer();
        timer.start();

        myStage.setTitle("Gravity");
        myStage.setScene(scene);
        myStage.show();
    }

    class GravityTimer extends AnimationTimer {

        @Override
        public void handle(long now) {

            // check boundary collision
            Bounds box = ball.getBoundsInLocal();

            // check edges of screen
            if (box.getMinX() < 0 || box.getMaxX() > scene.getWidth())
                dX *= -1;
            if (box.getMinY() < 0 || box.getMaxY() > scene.getHeight())
                dY *= -1; //reverse direction
            else
                dY += GRAVITY; //apply effect of gravity
               
            // update position
            ball.setCenterX(ball.getCenterX() + dX);
            ball.setCenterY(ball.getCenterY() + dY);

        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
