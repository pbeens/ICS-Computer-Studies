package activity3;

import java.net.URL;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ImageBounce extends Application {

    static final double SCREEN_WIDTH = 800;
    static final double SCREEN_HEIGHT = 600;

    static final double MAX_SPEED = 5.0;

    double dX = MAX_SPEED;
    double dY = MAX_SPEED;

    ImageView face;

    @Override
    public void start(Stage myStage) throws Exception {

        URL location = ImageBounce.class.getResource("/images/face.png");
        face = new ImageView(location.toString());

        Group root = new Group(face);

        BounceTimer timer = new BounceTimer();

        timer.start();

        Scene scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);

        myStage.setTitle("Bouncing Happy Face!");
        myStage.setScene(scene);
        myStage.show();

    }

    class BounceTimer extends AnimationTimer {

        @Override
        public void handle(long now) {
            // check boundary collision
            Bounds box = face.getBoundsInParent();

            // check edges of screen
            if (box.getMinX() < 0 || box.getMaxX() > SCREEN_WIDTH)
                dX *= -1;
            if (box.getMinY() < 0 || box.getMaxY() > SCREEN_HEIGHT)
                dY *= -1;

            // change the position of the face
            face.setX(face.getX() + dX);
            face.setY(face.getY() + dY);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
