package activity4;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class BallClicker extends Application {

    static final double SCREEN_WIDTH = 800;
    static final double SCREEN_HEIGHT = 600;

    static final int NUM_BALLS = 10;
    static final double MAX_SPEED = 3.0;
    static final double MIN_SPEED = 0.5;

    static final double BALL_SIZE = 75.0;

    double[] dX = new double[NUM_BALLS];
    double[] dY = new double[NUM_BALLS];

    Circle[] balls = new Circle[NUM_BALLS];

    @Override
    public void start(Stage myStage) throws Exception {

        for (int i = 0; i < balls.length; i++) {

            balls[i] = new Circle(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, BALL_SIZE, getRandomColour());

            balls[i].setOnMouseClicked(event -> handleBallClick(event));

            dX[i] = getRandomSpeedComponent();
            dY[i] = getRandomSpeedComponent();
        }

        Group root = new Group(balls);

        Scene scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);

        BallClickTimer timer = new BallClickTimer();
        timer.start();

        myStage.setTitle("Pop the Bubbles!");
        myStage.setScene(scene);
        myStage.show();

    }

    Paint getRandomColour() {
        int red = (int) (Math.random() * 256);
        int green = (int) (Math.random() * 256);
        int blue = (int) (Math.random() * 256);

        return Color.rgb(red, green, blue);
    }

    double getRandomSpeedComponent() {
        double speed = Math.random() * (MAX_SPEED - MIN_SPEED) + MIN_SPEED;
        double direction = Math.random() > 0.5 ? 1.0 : -1.0;
        return speed * direction;
    }

    class BallClickTimer extends AnimationTimer {

        @Override
        public void handle(long now) {

            for (int i = 0; i < balls.length; i++) {

                // check boundary collision
                Bounds box = balls[i].getBoundsInLocal();

                // check edges of screen
                if (box.getMinX() < 0 || box.getMaxX() > SCREEN_WIDTH)
                    dX[i] *= -1;
                if (box.getMinY() < 0 || box.getMaxY() > SCREEN_HEIGHT)
                    dY[i] *= -1;

                balls[i].setCenterX(balls[i].getCenterX() + dX[i]);
                balls[i].setCenterY(balls[i].getCenterY() + dY[i]);

            }
        }
    }

    private void handleBallClick(MouseEvent event) {
        // which circle did this click act upon?
        Object source = event.getSource();

        // check to ensure it is a Circle
        if (source instanceof Circle) {
            Circle bubble = (Circle) source;
            bubble.setVisible(false);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}