package activity2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class TemperatureConverterForm extends Application {

    public static final double SCREEN_WIDTH = 400;
    public static final double SCREEN_HEIGHT = 200;

    public static final double GAP = 10;
    public static final double SPACING = 20;
    
    //UI elements for input/output
    TextField txtFahrenheit;
    TextField txtCelsius;

    @Override
    public void start(Stage myStage) throws Exception {

        // Root Node
        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(GAP);
        root.setVgap(GAP);
        root.setPadding(new Insets(SPACING, SPACING, SPACING, SPACING));

        // Title
        Text sceneTitle = new Text("Temperature Converter");
        sceneTitle.setFont(Font.font(20));
        root.add(sceneTitle, 0, 0, 3, 1); // position (0,0); colspan = 3

        // Fahrenheit label & textfield
        Label lblFahrenheit = new Label("Temp in �F:");
        root.add(lblFahrenheit, 0, 1);
        txtFahrenheit = new TextField();
        root.add(txtFahrenheit, 1, 1);

        // Celsius label & textfield
        Label lblCelsuis = new Label("Temp in �C:");
        root.add(lblCelsuis, 0, 2);
        txtCelsius = new TextField();
        root.add(txtCelsius, 1, 2);

        // Buttons
        Button btnFToC = new Button();
        btnFToC.setText("Convert �F to �C");
        btnFToC.setOnAction(event -> convertFToC());
        // Add the button to the GridPane
        root.add(btnFToC, 2, 1);

        Button btnCToF = new Button();
        btnCToF.setText("Convert �C to �F");
        btnCToF.setOnAction(event -> convertCToF());
        // Add the button to the GridPane
        root.add(btnCToF, 2, 2);

        myStage.setTitle("Temperature Converter");
        myStage.setScene(new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT));
        myStage.show();

    }

    private void convertFToC() {
        // Variables
        double fTemp, cTemp;
        String strCelsius, strFahrenheit;

        // input
        strFahrenheit = txtFahrenheit.getText();

        // processing
        // make sure it is a valid number
        if (validateDouble(strFahrenheit)) {
            // Change the text into a number
            fTemp = Double.parseDouble(strFahrenheit);

            // Calculate the equivalent temperature
            cTemp = 5.0 / 9.0 * (fTemp - 32);

            // Convert back to a String
            strCelsius = String.valueOf(cTemp);
        } else {
            // error message to user
            strCelsius = "invalid temperature";
        }

        // output
        txtCelsius.setText(strCelsius);
    }

    private void convertCToF() {
        // Variables
        double fTemp, cTemp;
        String strCelsius, strFahrenheit;

        // input
        strCelsius = txtCelsius.getText();
        // processing
        // make sure it is a valid number
        if (validateDouble(strCelsius)) {
            // Change the text into a number
            cTemp = Double.parseDouble(strCelsius);

            // Calculate the equivalent temperature
            fTemp = 9.0 / 5.0 * cTemp + 32;

            // Convert back to a String
            strFahrenheit = String.valueOf(fTemp);
        } else {
            // error message to user
            strFahrenheit = "invalid temperature";
        }
        // output
        txtFahrenheit.setText(strFahrenheit);
    }

    private boolean validateDouble(String str) {
        // uses regular expressions to verify:
        // optional negative sign [-]?
        // one or more digits [0-9]+
        // optional decimal point [.]?
        // zero or more digits[0-9]*

        return str.matches("[-]?[0-9]+[.]?[0-9]*");
    }

    public static void main(String[] args) {
        launch(args);
    }

}
