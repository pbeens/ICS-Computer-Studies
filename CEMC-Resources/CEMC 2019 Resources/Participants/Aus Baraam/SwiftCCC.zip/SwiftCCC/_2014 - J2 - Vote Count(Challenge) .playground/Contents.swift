
import UIKit

// 2014 J2 (modified)

/*
 Problem Description:
 A vote is held after singer A and singer B compete in the final round of a singing competition. Your job is to count the votes and determine the outcome.
 
 Input Specification:
 The input will be two Arrays, one made up of integers, the other made up of strings. The first array will contain V (1 ≤ V ≤ 15), the total number of votes. The second line of input will be a sequence of V characters, each of which will be A or B, representing the votes for a particular singer.
 
 Output Specification
 The output will be a string and could be one of three possibilities:
 • "A won by n votes"
 • "B won by n votes"
 • "it's a tie by 0 votes"
 
 where "n" is a number of the difference in votes
 */

//B won by 6 votes
var counts1: [Int] = [6,8,3,5,2,4]
var votes1: [String] = ["AABBAA", "AAAABBBB", "BBB", "BBBBA", "BA", "BBAB"]

//A won by 4 votes
var counts2: [Int] = [5,4,4,5,2]
var votes2: [String] = ["AABAA", "AABB", "AAAA", "BBBBA", "BA",]

// its a tie by 0 votes
var counts3: [Int] = [3,4,5,6]
var votes3: [String] = ["ABA", "BBAA", "AABBA", "BBAABB"]




