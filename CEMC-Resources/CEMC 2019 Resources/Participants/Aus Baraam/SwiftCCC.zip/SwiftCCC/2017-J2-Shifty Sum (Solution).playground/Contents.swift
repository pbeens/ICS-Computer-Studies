import UIKit

func convertFilesToIntArray (fileName: String, fileExtention: String) -> [Int]{
    let one = Bundle.main.url(forResource: fileName, withExtension: fileExtention)
    var fileStringArray = (try! String(contentsOf: one!, encoding: String.Encoding.utf8)).components(separatedBy: "\n")
    fileStringArray.removeLast()
    // can remove the for looop if there are no spaces in the numbers in the file.
    for index in 0..<fileStringArray.count {
        fileStringArray[index] = fileStringArray[index].replacingOccurrences(of: " ", with: "")
    }
    let finalFile = fileStringArray.map({Int ($0)!})
    return finalFile
}

let fileOne = convertFilesToIntArray(fileName: "j2.01", fileExtention: ".in")
let fileTwo = convertFilesToIntArray(fileName: "j2.02", fileExtention: ".in")
let fileThree = convertFilesToIntArray(fileName: "j2.03", fileExtention: ".in")
let fileFour = convertFilesToIntArray(fileName: "j2.04", fileExtention: ".in")
let fileFive = convertFilesToIntArray(fileName: "j2.05", fileExtention: ".in")
let fileSix = convertFilesToIntArray(fileName: "j2.06", fileExtention: ".in")
let fileSeven = convertFilesToIntArray(fileName: "j2.07", fileExtention: ".in")
let fileEight = convertFilesToIntArray(fileName: "j2.08", fileExtention: ".in")
let fileNine = convertFilesToIntArray(fileName: "j2.09", fileExtention: ".in")
let fileTen = convertFilesToIntArray(fileName: "j2.10", fileExtention: ".in")


/*
 Problem J2: Shifty Sum
 
 Problem Description
 Suppose we have a number like 12. Let’s define shifting a number to mean adding a zero at the end. For example, if we shift that number once, we get the number 120. If we shift the number again we get the number 1200. We can shift the number as many times as we want. In this problem you will be calculating a shifty sum, which is the sum of a number and the numbers we get by shifting. Specifically, you will be given the starting number N and a non-negative integer k. You must add together N and all the numbers you get by shifting a total of k times. For example, the shifty sum when N is 12 and k is 1 is: 12 + 120 = 132. As another example, the shifty sum when N is12 and k is 3 is 12+120+1200+12000=13332.
 
 Input Specification
 The first line of input contains the number N (1 ≤ N ≤ 10000). The second line of input contains k, the number of times to shift N (0 ≤ k ≤ 5).
 
 Output Specification
 Output the integer which is the shifty sum of N by k.
 
 Sample Input
 12 3
 
 Output for Sample Input
 13332
 
 */

var sample: [Int] = [12,3]

func findAnswer (myArray: [Int]) -> Int {
    var sum = 0
    
    if myArray[1] == 1 {
        sum = myArray[0] + (myArray[0] * 10)
    } else if myArray[1] == 2 {
        sum = myArray[0] + (myArray[0] * 10) + (myArray[0] * 100)
    } else if myArray[1] == 3 {
        sum = myArray[0] + (myArray[0] * 10) + (myArray[0] * 100) + (myArray[0] * 1000)
    } else if myArray[1] == 4 {
        sum = myArray[0] + (myArray[0] * 10) + (myArray[0] * 100) + (myArray[0] * 1000) + (myArray[0] * 10_000)
    } else if myArray[1] == 5 {
        sum = myArray[0] + (myArray[0] * 10) + (myArray[0] * 100) + (myArray[0] * 1000) + (myArray[0] * 10_000) + (myArray[0] * 100_000)
    } else {
        sum = myArray[0]
    }
    
    return sum
}

//findAnswer(myArray: sample)
findAnswer(myArray: fileOne)
findAnswer(myArray: fileTwo)
findAnswer(myArray: fileThree)
findAnswer(myArray: fileFour)
findAnswer(myArray: fileFive)
findAnswer(myArray: fileSix)
findAnswer(myArray: fileSeven)
findAnswer(myArray: fileEight)
findAnswer(myArray: fileNine)
findAnswer(myArray: fileTen)



















