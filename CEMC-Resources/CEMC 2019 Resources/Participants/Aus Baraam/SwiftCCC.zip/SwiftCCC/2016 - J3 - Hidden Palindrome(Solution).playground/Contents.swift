import UIKit

let inputOne = "banana"
let inputTwo = "abracadabra"
let inputThree = "abba"
let inputFour = "hefjhhgatlmn"
let inputFive = "badefghhgfghbcb"
let inputSix = "abccbaabccbadefghhhgfabcdeedc"
let inputseven = "abacbcabcdefcbaabadeedcdefghababahgf"





func findLongestPalindrom (input:String) -> Int{
    var longestFound: Int = 1
    let realInput = input
    var reversedString = String(realInput.reversed())
    var checkString = realInput
    var prefixString: String = ""
    
    for index in 2...realInput.count {
        
        for _ in 0...realInput.count - index {
            prefixString = String(checkString.prefix(index))
            reversedString = String(prefixString.reversed())
        
                if prefixString == reversedString {
                longestFound = prefixString.count
                }
            checkString.removeFirst()
        }
        
        
        checkString = realInput
    }
    return longestFound
}

findLongestPalindrom(input: inputseven)

