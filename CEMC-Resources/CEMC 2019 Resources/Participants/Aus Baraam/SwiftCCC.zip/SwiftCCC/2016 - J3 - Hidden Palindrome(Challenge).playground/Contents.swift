import UIKit

let inputOne = "banana" //5
let inputTwo = "abracadabra"
let inputThree = "abba" //4
let inputFour = "hefjhhgatlmn" //2
let inputFive = "badefghhgfghbcb" //6
let inputSix = "abccbaabccbadefghhhgfabcdeedc"
let inputseven = "abacbcabcdefcbaabadeedcdefghababahgf"

/*
 Problem Description:
 
A palindrome is a word which is the same when read forwards as it is when read backwards. For example, mom and anna are two palindromes.A word which has just one letter, such as a, is also a palindrome. Given a word, what is the longest palindrome that is contained in the word? That is, what is the longest palindrome that we can obtain, if we are allowed to delete characters from the beginning and/or the end of the string?
 
 Input Specification:
 The input will consist of the above string constants, containing a sequence of at least 1 and at most 40 lowercase letters.
 
 Output Specification:
 Output the total number of letters of the longest palindrome contained in the input word.
 */
