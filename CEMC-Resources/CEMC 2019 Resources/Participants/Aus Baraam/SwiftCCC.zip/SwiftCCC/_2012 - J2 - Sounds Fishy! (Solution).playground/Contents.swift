import UIKit

/*
 
 Problem Description:
 
 A fish-finder is a device used by anglers to find fish in a lake. If the fish-finder finds a fish, it will sound an alarm. It uses depth readings to determine whether to sound an alarm. For our purposes, the fish-finder will decide that a fish is swimming past if:
 • there are four consecutive depth readings which form a strictly increasing sequence (such as 3 4 7 9) (which we will call “Fish Rising”), or
 • there are four consecutive depth readings which form a strictly decreasing sequence (such as 9 6 5 2) (which we will call “Fish Diving”), or
 • there are four consecutive depth readings which are identical (which we will call “Constant Depth”).
 All other readings will be considered random noise or debris, which we will call “No Fish.” Your task is to read a sequence of depth readings and determine if the alarm will sound.
 
 Input Specification:
 The input will be four positive integers in an array, representing the depth readings.
 
 Output Specification:
 The output is one of four possibilities in the form of a string. If the depth readings are increasing, then the output should be "Fish Rising". If the depth readings are decreasing, then the output should be "Fish Diving". If the depth readings are identical, then the output should be Fish At "Constant Depth".Otherwise,the outputs hould be "No Fish".
 
 Sample Input 1: [30 10 20 20]
 Output for Sample Input 1: "No Fish"
 
 Sample Input 2: [1 10 12 13]
 Output for Sample Input 2: "Fish Rising"
 
 */




//func findAnswerOne (array: [Int]) -> String {
//
//    if array[0] < array[1] && array[1] < array[2] && array[2] < array[3] {
//        return "fish rising"
//    } else if array[0] > array[1] && array[1] > array[2] && array[2] > array[3] {
//        return "fish diving"
//    } else if array[0] == array[1] && array[1] == array[2] && array[2] == array[3] {
//        return "constant depth"
//    } else {
//        return "no fish"
//    }
//
//  return ""
//}
//
//findAnswerOne(array: arrayOne)
//findAnswerOne(array: arrayTwo)
//findAnswerOne(array: arrayThree)
//findAnswerOne(array: arrayFour)
//


var arrayOne: [Int] = [2,15,17,22,77,76] // fish rising
var arrayTwo: [Int] = [5,4,3,1] // fish diving
var arrayThree: [Int] = [55,55,55,55,55,55,55,55,1] // constant depth
var arrayFour: [Int] = [11,24,25,22] // no fish

func fishFinder (array: [Int]) -> String {
    
    var fishAction: [Double] = [] //1-fish rising, 2-fish diving, 3-constant depth,
    var stringResult: String = ""
    var fishActionSum: Double = 0.0
    
    for index in 0..<array.count - 1{
        if array[index] < array[index + 1] {
            fishAction.append(1.0)
        } else if array[index] > array[index + 1] {
            fishAction.append(2.0)
        } else if array[index] == array[index] {
            fishAction.append(3.0)
        }
    }
    
    
    for index in 0..<fishAction.count {
        fishActionSum += fishAction[index]
    }
    
    if fishActionSum / Double(fishAction.count) == 1.0 {
        stringResult = "fish rising"
    } else if fishActionSum / Double(fishAction.count) == 2.0 {
        stringResult = "fish diving"
    } else if fishActionSum / Double(fishAction.count) == 3.0 {
        stringResult = "constant depth"
    } else {
        stringResult = "no fish"
    }
    
    
    return stringResult
}

fishFinder(array: arrayOne)
fishFinder(array: arrayTwo)
fishFinder(array: arrayThree)
fishFinder(array: arrayFour)

