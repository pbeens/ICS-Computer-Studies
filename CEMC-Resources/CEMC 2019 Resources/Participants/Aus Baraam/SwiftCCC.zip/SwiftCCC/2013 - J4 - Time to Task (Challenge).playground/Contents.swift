import UIKit
func ConvertFiles (fileName: String, fileExtention: String) -> [Int]{
    var finalFile: [Int] = []
    let one = Bundle.main.url(forResource: fileName, withExtension: fileExtention)
    let fileString = try? String(contentsOf: one!, encoding: String.Encoding.utf8)
    var fileStringArray = fileString!.components(separatedBy: NSCharacterSet.newlines)
    fileStringArray.removeLast()
    for index in fileStringArray {finalFile.append(Int(index)!)}
    return finalFile
}
/*
 Problem Description:
 You have been asked by a parental unit to do your chores. Each chore takes a certain amount of time, but you may not have enough time to do all of your chores, since you can only complete one chore at a time. You can do the chores in any order that you wish. What is the largest amount of chores you can complete in the given amount of time?
 
 Input Specification:
 - The first line of input consists of an integer T (0 ≤ T ≤ 100000), which is the total number of minutes you have available to complete your chores.
 - The second line of input consists of an integer C (0 ≤ C ≤ 100), which is the total number of chores that you may choose from. The next C lines contain the (positive integer) number of minutes required to do each of these chores. You can assume that each chore will take at most 100000 minutes.
 
 Output Specification:
 The output will be the maximum number of chores that can be completed in time T .
 
 */

var fileOne: [Int] = ConvertFiles(fileName: "j4.1", fileExtention: ".in")
var fileTwo: [Int] = ConvertFiles(fileName: "j4.2", fileExtention: ".in")
var fileThree: [Int] = ConvertFiles(fileName: "j4.3", fileExtention: ".in")
var fileFour: [Int] = ConvertFiles(fileName: "j4.4", fileExtention: ".in")
var fileFive: [Int] = ConvertFiles(fileName: "j4.5", fileExtention: ".in")

var sampleFile: [Int] = [6,3,3,6,3] //2
