
import UIKit

//B won by 6 votes
var counts1: [Int] = [6,8,3,5,2,4]
var votes1: [String] = ["AABBAA", "AAAABBBB", "BBB", "BBBBA", "BA", "BBAB"]

//A won by 4 votes
var counts2: [Int] = [5,4,4,5,2,1]
var votes2: [String] = ["AABAA", "AABB", "AAAA", "BBBBA", "BA", "A"]

// its a tie by 0 votes
var counts3: [Int] = [3,4,5,6]
var votes3: [String] = ["ABA", "BBAA", "AABBA", "BBAABB"]



func findAnswer (arrayOfInt: [Int], arrayOfString: inout [String]) -> String{
    
    var countA = 0
    var countB = 0
    var winner = ""
    var difference = 0
    
    for index in 0..<arrayOfString.count {
        
        for index2 in 0..<arrayOfString[index].count {
            if arrayOfString[index].first! == "A" {
                countA += 1
            } else {
                countB += 1
            }
            arrayOfString[index].removeFirst()
        }
    }
    
    if countA > countB {
        winner = "A won"
    } else if countA < countB {
        winner = "B won"
    } else {
        winner = "its a tie"
    }
    
    if winner == "A won" {
        difference = countA - countB
    } else if winner == "B won"{
        difference = countB - countA
    } else {
        
    }
    
    print(countA)
    print(countB)

    
    return ("\(winner) by \(difference) votes")
}


findAnswer(arrayOfInt: counts1, arrayOfString: &votes1)
findAnswer(arrayOfInt: counts2, arrayOfString: &votes2)
findAnswer(arrayOfInt: counts3, arrayOfString: &votes3)

//func CharacterRecurrence (Of CharacterLookingFor: Character, In StringToAnalyze: String) -> Int {
//
//    var count: Int = 0
//
//    for myCharacter in StringToAnalyze{
//        if myCharacter == CharacterLookingFor {
//            count += 1
//        }
//    }
//    return count
//}
//
//func CalculateVotes (countsArray: [Int], stringArray: [String]) -> (String, Int) {
//
//    var sumOfCounts = 0
//    var numberOfA = 0
//    var numberOfB = 0
//    var stringResult = ""
//    var differenceInResult = 0
//
//    for index in 0..<countsArray.count {
//        sumOfCounts = sumOfCounts + countsArray[index]
//    }
//    for someIndex in 0..<stringArray.count {
//        numberOfA = numberOfA + CharacterRecurrence(Of: "A", In: stringArray[someIndex])
//    }
//
//    for someIndex in 0..<stringArray.count {
//        numberOfB = numberOfB + CharacterRecurrence(Of: "B", In: stringArray[someIndex])
//    }
//
//    if numberOfA > numberOfB {
//        stringResult = "A won"
//        differenceInResult = numberOfA - numberOfB
//    } else if numberOfA < numberOfB {
//        stringResult = "B won"
//        differenceInResult = numberOfB - numberOfA
//    } else {
//        stringResult = "its a tie"
//        differenceInResult = 0
//    }
//
//
//
//    return (stringResult, differenceInResult)
//
//}
//
//CalculateVotes(countsArray: counts1, stringArray: votes1)
//CalculateVotes(countsArray: counts2, stringArray: votes2)
//CalculateVotes(countsArray: counts3, stringArray: votes3)


