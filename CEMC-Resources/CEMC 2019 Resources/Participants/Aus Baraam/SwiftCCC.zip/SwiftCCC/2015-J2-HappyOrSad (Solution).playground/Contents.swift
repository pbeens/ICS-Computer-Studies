import UIKit

func convertFilesToString (fileName: String, fileExtention: String) -> String{
    let one = Bundle.main.url(forResource: fileName, withExtension: fileExtention)
    let fileString = try! String(contentsOf: one!, encoding: String.Encoding.utf8)
    return fileString
}

let fileThree = convertFilesToString(fileName: "j2.3", fileExtention: ".in")
let fileFour = convertFilesToString(fileName: "j2.4", fileExtention: ".in")
let fileFive = convertFilesToString(fileName: "j2.5", fileExtention: ".in")
let fileSix = convertFilesToString(fileName: "j2.6", fileExtention: ".in")
let fileSeven = convertFilesToString(fileName: "j2.7", fileExtention: ".in")


/*
 Problem Description
 We often include emoticons in our text messages to indicate how we are feeling. The three con- secutive characters :-) indicate a happy face and the three consecutive characters :-( indicate a sad face. Write a program to determine the overall mood of a message.

 Input Specification
 There will be one line of input that contains between 1 and 255 characters.
 
 Output Specification
 The output is determined by the following rules:
 • If the input line does not contain any happy or sad emoticons, output none.
 • Otherwise, if the input line contains an equal number of happy and sad emoticons, output unsure.
 • Otherwise, if the input line contains more happy than sad emoticons, output happy. • Otherwise, if the input line contains more sad than happy emoticons, output sad.
 
 Sample Input 1
 How are you :-) doing :-( today :-)?
 Output for Sample Input 1
 happy
 
 Sample Input 2
 :)
 Output for Sample Input 2
 none
 
 Sample Input 3
 This:-(is str:-(:-(ange te:-)xt.
 Output for Sample Input 3
 sad
 
 */

func findAnswer (aString: String) -> String{
    var first: Bool = false
    var second: Bool = false
    var third: Bool = false
    
    var happyCount = 0
    var sadCount = 0
    
    var answer: String = ""
    
    for index in aString {
        print(index)
        if first == false {
            if index == ":" {
                first = true
                continue
            }
        }
        
        if first == true && second == false {
            if index == "-" {
                second = true
                continue
            }
        }
        
        if first == true && second == true {
            if index == ")" {
                happyCount += 1
            } else if index == "(" {
                sadCount += 1
            }
        }
        
        first = false; second = false; third = false

    }
    
    if happyCount == 0 && sadCount == 0 {
        answer = "none"
    } else if happyCount == sadCount {
        answer = "unsure"
    } else if happyCount > sadCount {
        answer = "happy"
    } else {
        answer = "sad"
    }
    
    return answer
}

findAnswer(aString: fileThree)
findAnswer(aString: fileFour)
findAnswer(aString: fileFive)
findAnswer(aString: fileSix)
findAnswer(aString: fileSeven)

