import UIKit

/*
 
 
 When a credit card number is sent through the Internet it must be protected so that other people cannot see it. Many web browsers use a protection based on "RSA Numbers."
 A number is an RSA number if it has exactly four divisors. In other words, there are exactly four numbers that divide into it evenly. For example, 10 is an RSA number because it has exactly four divisors (1, 2, 5, 10). 12 is not an RSA number because it has too many divisors (1, 2, 3, 4, 6, 12). 11 is not an RSA number either. There is only one RSA number in the range 10...12.
 Write a program that inputs a range of numbers and then counts how many numbers from that range are RSA numbers. You may assume that the numbers in the range are less than 1000.
 
 
 
 Sample Session 1
 Input:  [10,12] --> thats a range, 10 to 12
 output: 1 --> Because 10 is the only RSA, 11 and 12 are not RSA numbers
 
 Sample Session 1
 Input:  [11,15] --> thats a range, 11 to 15
 output: 2 --> There are only 2 numbers in the range of 11...15 that qualify as RSA --> Only 14 (1,2,7,14) and 15 (1,3,5,15).
 
*** NOTE: your output needs only be a number (how many numbers in the range qualify as an RSA number" I dont need an explantion. so for [10,12] simply output the number 1, and for [11,15] simply output 2. ***
 */


let rangeOne : [Int] = [5,6]
let rangeTwo: [Int] = [21,26]
let rangeThree: [Int] = [99,999]


func Answer (lowerRange: Int, upperRange: Int) -> Int {
    var result = 0
    var count = 0
    var RSACount = 0
    
    for index in lowerRange...upperRange {
        count = 0
        
        for index2 in 1...index {
            result = index % index2
            if result == 0 {
                count += 1
            }
            if index2 == index {
                if count == 4 {
                    RSACount += 1
                }
            }
        }
    }
    return RSACount
}

Answer(lowerRange: rangeOne[0], upperRange: rangeOne[1])
Answer(lowerRange: rangeTwo[0], upperRange: rangeTwo[1])
Answer(lowerRange: rangeThree[0], upperRange: rangeThree[1])
















