import UIKit

/*
 
 Problem Description:
 You have been asked to take a small icon that appears on the screen of a smart telephone and scale it up so it looks bigger on a regular computer screen.
 
 The icon will be encoded as characters (x and *) in a 3 × 3 grid as follows:
 
 *x*
  xx
 * *
 
 Write a program that accepts a positive integer scaling factor and outputs the scaled icon. A scaling factor of k means that each character is replaced by a k × k grid consisting only of that character.
 
 Input Specification:
 The input will be a positive integer k such that k < 25.
 
 Output Specification:
 The output will be 3k lines, which represent each individual line scaled by a factor of k and repeated k times. A line is scaled by a factor of k by replacing each character in the line with k copies of the character.
 
 
 NOTE: I WANT YOUR ANSWERS PRINTED IN THE CONSOLE (NOT RETURNED). I NEED YOUR ANSWERS TO VISUALLY LOOK LIKE THE OUTPUT SHOWN BELOW. ALSO, PLEASE PRINT A LINE OF DASHES (as shown on line 24) IN BETWEEN THE ANSWERS FOR THE DIFFERENT FILES
 print("--------------------------------------------------------------------------------")
 
 
 Sample Input
 3
 
 Output for Sample Input
 ***xxx***
 ***xxx***
 ***xxx***
    xxxxxx
    xxxxxx
    xxxxxx
 ***   ***
 ***   ***
 ***   ***
 
 */


let fileOne = 2
let fileTwo = 4
let fileThree = 5
let fileFour = 6
let fileFive = 9

func findAnswer (inputFile: Int) {
    let originalIcon: [String] = ["*X*", " XX", "* *"]
    
    var finalAnswer: [String] = []
    
    var newFirstLine: String = ""
    var newSecondLine: String = ""
    var newThirdLine: String = ""
    var arrayOfNewLines: [String] = []
    
    //loop for new first line
    for indexOne in originalIcon[0] {
        for _ in 1...inputFile {
            newFirstLine.append(indexOne)
        }
    }
    arrayOfNewLines.append(newFirstLine)
    
    //loop for new second line
    for indexOne in originalIcon[1] {
        for _ in 1...inputFile {
            newSecondLine.append(indexOne)
        }
    }
    arrayOfNewLines.append(newSecondLine)
    
    //loop for new third line
    for indexOne in originalIcon[2] {
        for _ in 1...inputFile {
            newThirdLine.append(indexOne)
        }
    }
    arrayOfNewLines.append(newThirdLine)
    
    
    //final Answer, add all the new lines coressponding with the amount of input file
    for index in arrayOfNewLines {
        for _ in 1...inputFile {
            finalAnswer.append(index)
        }
    }
    
    //print finalAnswer with lines seperated
    for index in finalAnswer {
        print(index)
    }
}



findAnswer(inputFile: fileOne)
print("-----------------------------------------------------------------------------")
findAnswer(inputFile: fileTwo)
print("-----------------------------------------------------------------------------")
findAnswer(inputFile: fileThree)
print("-----------------------------------------------------------------------------")
findAnswer(inputFile: fileFour)
print("-----------------------------------------------------------------------------")
findAnswer(inputFile: fileFive)
print("-----------------------------------------------------------------------------")


