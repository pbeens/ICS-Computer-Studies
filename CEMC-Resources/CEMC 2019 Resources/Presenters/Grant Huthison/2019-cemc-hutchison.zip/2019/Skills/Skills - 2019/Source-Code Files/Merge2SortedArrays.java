// Java program to merge two sorted arrays   
class Merge2SortedArrays 
{ 
    public static void main (String[] args)  
    { 
        int[] array1 = { 1, 2, 3, 5}; 
        int[] array2 = { 0, 2, 4, 6, 8 };
        
        // Create merge result array
        int[] result = new int[array1.length + array2.length];
        
        // Initialize array indices
        int indexArray1 = 0;
        int indexArray2 = 0;
        int indexResult = 0; 
        
        // Traverse array1 and array2
        while (indexArray1 < array1.length && indexArray2 < array2.length) 
        { 
            // Compare current elements from array1 and array2.
            // Put the smaller element into the result array.
            if (array1[indexArray1] < array2[indexArray2]) 
                result[indexResult++] = array1[indexArray1++]; 
            else
                result[indexResult++] = array2[indexArray2++]; 
        } 
        
        // Store any remaining elements of array1 
        while (indexArray1 < array1.length) 
            result[indexResult++] = array1[indexArray1++]; 
        
        // Store any remaining elements of array2 
        while (indexArray2 < array2.length) 
            result[indexResult++] = array2[indexArray2++]; 
        
        System.out.println("Result after merging:"); 
        for (int element : result) 
            System.out.print(element + " "); 
    }     
} 