using System;

class Merge2SortedArrays {
    public static void Main (string[] args) {
        int[] array1 = {1, 3, 5, 7}; 
        int[] array2 = {0, 2, 4, 5, 6, 8};
        
        // Create merge result array
        int[] result = new int[array1.Length + array2.Length];
        
        // Initialize array indices
        int indexArray1 = 0;
        int indexArray2 = 0;
        int indexResult = 0; 
        
        // Traverse array1 and array2
        while (indexArray1 < array1.Length && indexArray2 < array2.Length) 
        { 
            // Compare current elements from array1 and array2.
            // Put the smaller element into the result array.
            if (array1[indexArray1] < array2[indexArray2]) 
                result[indexResult++] = array1[indexArray1++]; 
            else
                result[indexResult++] = array2[indexArray2++]; 
        } 
        
        // Store any remaining elements of array1 
        while (indexArray1 < array1.Length) 
            result[indexResult++] = array1[indexArray1++]; 
        
        // Store any remaining elements of array2 
        while (indexArray2 < array2.Length) 
            result[indexResult++] = array2[indexArray2++]; 
        
        Console.WriteLine("Result after merging:"); 
        foreach (int element in result) 
            Console.Write(element + " ");
    }
}